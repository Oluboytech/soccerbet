                         <div class="tab-1 tab-content current fb-sb-list">
                          <a class="fb-sb-wrapper bg-offset-betway side-bet-ext_event ppc-betway" title="Get a £30 Free Bet!" target="_blank" href="http://bit.ly/100BetwaySidebarFST">
                              <div class="fb-sb-head bg-betway">
                                 <h4>Get a £30 Free Bet!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ £10 Free Bet Every Week<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-william-hill side-bet-ext_event ppc-william-hill" title="Bet £10, Get £30 In Free Bets!" target="_blank" href="http://bit.ly/FSTSidebarWH30">
                              <div class="fb-sb-head bg-william-hill">
                                 <h4>Bet £10, Get £30 In Free Bets!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Accumulator Insurance<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betvictor side-bet-ext_event ppc-betvictor" title="Bet £10, Get £40 Free Bets!" target="_blank" href="http://bit.ly/FSTsidebar30">
                              <div class="fb-sb-head bg-betvictor">
                                 <h4>Bet £10, Get £40 Free Bets!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Cash Out<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-genting side-bet-ext_event ppc-genting" title="Get a £25 Free Bet!" target="_blank" href="http://bit.ly/FSTSidebarGenting22">
                              <div class="fb-sb-head bg-genting">
                                 <h4>Get a £25 Free Bet!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ 10 Free Casino Spins!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-ladbrokes side-bet-ext_event ppc-ladbrokes" title="Get a Free Bet Up To £50!" target="_blank" href="http://bit.ly/FSTSidebarLads50">
                              <div class="fb-sb-head bg-ladbrokes">
                                 <h4>Get a Free Bet Up To £50!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Daily Oddsboost<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-coral side-bet-ext_event ppc-coral" title="Bet £10, Get £30 In Free Bets!" target="_blank" href="http://bit.ly/CoralBet10Get30FSTSidebar2">
                              <div class="fb-sb-head bg-coral">
                                 <h4>Bet £10, Get £30 In Free Bets!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Acca Insurance &amp; Cash Out<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="Get up to £100 in Free Bets!" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/FSTSidebarBF">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>Get up to £100 in Free Bets!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Weekly Winning Accumulator Bonuses<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-paddy-power side-bet-ext_event ppc-paddy-power" title="Get a £20 Risk Free First Bet!" target="_blank" href="http://bit.ly/PPSidebarNEW">
                              <div class="fb-sb-head bg-paddy-power">
                                 <h4>Get a £20 Risk Free First Bet!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ Money Back In Cash If It Loses<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-888 side-bet-ext_event ppc-888" title="Bet £10, Get £30 In Free Bets!" target="_blank" href="http://bit.ly/FSTSidebar88810get30">
                              <div class="fb-sb-head bg-888">
                                 <h4>Bet £10, Get £30 In Free Bets!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">+ £10 Casino bonus<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betbright side-bet-ext_event ppc-betbright" title="Deposit £10, Play with £50!" target="_blank" href="http://bit.ly/BetbrightBet10Get50Side">
                              <div class="fb-sb-head bg-betbright">
                                 <h4>Deposit £10, Play with £50!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New BetBright customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
</div>
<!-- end tab one -->
<div class="tab-2 tab-content fb-sb-list">
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="25/1 Chelsea to beat West Ham!" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/FSTSpecials22">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>25/1 Chelsea to beat West Ham!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-coral side-bet-ext_event ppc-coral" title="28/1 Chelsea to beat West Ham!" target="_blank" href="http://bit.ly/CoralFootball4">
                              <div class="fb-sb-head bg-coral">
                                 <h4>28/1 Chelsea to beat West Ham!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="25/1 Arsenal to beat Southampton!" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/FSTSpecials19">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>25/1 Arsenal to beat Southampton!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-ladbrokes side-bet-ext_event ppc-ladbrokes" title="25/1 Liverpool to beat Everton!" target="_blank" href="http://bit.ly/25to1LIVLadsFST">
                              <div class="fb-sb-head bg-ladbrokes">
                                 <h4>25/1 Liverpool to beat Everton!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="25/1 Liverpool to beat Everton!" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/FSTSpecials25">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>25/1 Liverpool to beat Everton!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-coral side-bet-ext_event ppc-coral" title="25/1 A yellow card to be shown in Man Utd vs Man City!" target="_blank" href="http://bit.ly/CoralFootball1">
                              <div class="fb-sb-head bg-coral">
                                 <h4>25/1 A yellow card to be shown in Man Utd vs Man City!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="40/1 Man United vs 30/1 Man City!" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/FSTSpecials15">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>40/1 Man United vs 30/1 Man City!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Paid in Free Bets!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betbright side-bet-ext_event ppc-betbright" title="The Ashes Cricket – Deposit £50. Play with £150!" target="_blank" href="http://bit.ly/d50p150BBFST">
                              <div class="fb-sb-head bg-betbright">
                                 <h4>The Ashes Cricket – Deposit £50. Play with £150!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">for New BetBright Customers!<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betway side-bet-ext_event ppc-betway" title="£10 In Free Bets Every Week" target="_blank" href="http://bit.ly/FreeBetClubFST">
                              <div class="fb-sb-head bg-betway">
                                 <h4>£10 In Free Bets Every Week</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Opt in now to claim yours<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair side-bet-ext_event ppc-betfair" title="20% Bonus Profit With Acca Edge" target="_blank" href="http://www.freesupertips.co.uk/freebet-redirect/?ru=http://bit.ly/BetfairExistingFST">
                              <div class="fb-sb-head bg-betfair">
                                 <h4>20% Bonus Profit With Acca Edge</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">Applies to your first edged acca each week<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                        </div>
                        <!-- end tab two -->
                        <div class="tab-3 tab-content fb-sb-list">
                           <a class="fb-sb-wrapper bg-offset-betway side-bet-ext_event ppc-betway" title="Up to £1000 Casino Welcome Bonus!" target="_blank" href="http://bit.ly/FSTBWcasino">
                              <div class="fb-sb-head bg-betway">
                                 <h4>Up to £1000 Casino Welcome Bonus!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New Betway casino customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-ladbrokes-casino side-bet-ext_event ppc-ladbrokes-casino" title="£500 Bonus up to 100% Matched!" target="_blank" href="http://bit.ly/LadsCasinoSidebar">
                              <div class="fb-sb-head bg-ladbrokes-casino">
                                 <h4>£500 Bonus up to 100% Matched!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New Ladbrokes casino customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-paddy-power-casino side-bet-ext_event ppc-paddy-power-casino" title="£500 Deposit Bonus + £10 Free bonus!" target="_blank" href="http://bit.ly/PPCasinoFST">
                              <div class="fb-sb-head bg-paddy-power-casino">
                                 <h4>£500 Deposit Bonus + £10 Free bonus!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New Paddy Power casino customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-mr-green-casino side-bet-ext_event ppc-mr-green-casino" title="£100 Bonus + 420 Bonus Spins!" target="_blank" href="http://bit.ly/MrGreenFBSidebarFST">
                              <div class="fb-sb-head bg-mr-green-casino">
                                 <h4>£100 Bonus + 420 Bonus Spins!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New Mr Green casino customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                           <a class="fb-sb-wrapper bg-offset-betfair-casino side-bet-ext_event ppc-betfair-casino" title="£100 Bonus up to 100% Matched!" target="_blank" href="http://bit.ly/BetfairCasinoFST2">
                              <div class="fb-sb-head bg-betfair-casino">
                                 <h4>£100 Bonus up to 100% Matched!</h4>
                              </div>
                              <div class="fb-sb-content">
                                 <div class="fb-sb-subhead">New Betfair casino customers<br><span>New customers only. T&amp;Cs apply, 18+, begambleaware.org</span></div>
                                 <div class="fb-sb-button-wrapper">
                                    <div class="fb-sb-button">Claim Now</div>
                                 </div>
                              </div>
                           </a>
                        </div>
                        <!-- end tab three -->
                        <div class="followers-widget">
                        <a class="follow twitter" href="http://twitter.com/FootySuperTips" target="_blank"><span><strong>380,888</strong> Followers</span></a><a class="follow facebook" href="http://www.facebook.com/groups/freesupertips/" target="_blank"><span><strong>16,786</strong> Followers</span></a>
                        <div style="clear:both;"></div>
                     </div>
                     <div class="desktop"></div>
                  </div>
                  <div id="league-featured-articles" class="sidebar-winning desktop">
<?php $args = array( 'post_type' => 'recent_winners', 'posts_per_page' => 2 );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post();
          ?>  
                   <a class="league-article total-cols-2 home-winning" href="<?php the_permalink() ?>">
                        <h3 class="home-winning">Recent Winners</h3>
                        <!-- <img width="200" height="200" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/nhl-acca-200x200.png" class="attachment-blog-thumb size-blog-thumb wp-post-image" alt="" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/12/nhl-acca-200x200.png 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/nhl-acca-150x150.png 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/nhl-acca-100x100.png 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/nhl-acca-50x50.png 50w" sizes="(max-width: 200px) 100vw, 200px"> -->
                        <?php the_post_thumbnail('full');?>
                        <div class="league-text">
                           <h4>9/1 NHL Accumulator and Double land on Thursday night!</h4>
                           <!--<p class="sub-head-date">8th December</p>-->
                           <p>December is the season of giving and our tipsters have contributed to the festive mood with yet another winner! After…</p>
                        </div>
                     </a>
                  <?php endwhile;?>
                     
                  </div>

<div class="sidebar-tips desktop">
                     <h2 class="preview-dark-heading ft">Today's Tips</h2>
                     <?php $args = array( 'post_type' => 'tips', 'posts_per_page' => 6 );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post();
          ?>  
                     <a href=<?php the_permalink() ?> class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date"><?php the_field('date');?></div>
                           <div class="time"><?php the_field('time');?></div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4><?php the_title();?></h4>
                           <p class="tip-sub"><?php the_field('tip_subtitle');?></p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a>
                  <?php endwhile;?>
                     <!-- <a href="http://www.freesupertips.co.uk/both-teams-to-score-tips/" class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date">December 08</div>
                           <div class="time">19:00</div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4>Both Teams To Score Accumulator</h4>
                           <p class="tip-sub">£10 returns £177.30</p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a>
                     <a href="http://www.freesupertips.co.uk/both-teams-to-score-and-win-accumulator/" class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date">December 08</div>
                           <div class="time">19:00</div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4>Both Teams To Score &amp; Win Treble</h4>
                           <p class="tip-sub">£10 returns £337.50</p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a>
                     <a href="http://www.freesupertips.co.uk/tips/match-goals-accumulator-52/" class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date">December 08</div>
                           <div class="time">19:00</div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4>Match Goals Accumulator</h4>
                           <p class="tip-sub">£10 returns £225.60</p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a>
                     <a href="http://www.freesupertips.co.uk/tips/correct-score-double-259/" class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date">December 08</div>
                           <div class="time">19:30</div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4>Correct Score Double</h4>
                           <p class="tip-sub">£10 returns £810.00</p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a>
                     <a href="http://www.freesupertips.co.uk/bankroll-builder/" class="tip featured-tip">
                        <div class="tip-start">
                           <div class="date">December 08</div>
                           <div class="time">19:45</div>
                        </div>
                        <div class="tip-button hide-500">View Tip</div>
                        <div class="tip-title">
                           <h4>Bankroll Builder</h4>
                           <p class="tip-sub">Daily tips to build your bankroll!</p>
                           <div class="tip-button show-500">View Tip</div>
                        </div>
                        <div style="clear:both;"></div>
                     </a> -->
                  </div>



                  <!-- hide blog on festive five page --> <!-- START BLOG -->
                  <div class="ui horizontal divider invis_clss"> <i class="ui white custom blog icon"></i> Betting Blog</div>
                  <div class="ui list blog">
                     <?php $args = array( 'post_type' => 'blog', 'posts_per_page' => 10 );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post();
          ?>  
                     <a class="item blog_block" href=<?php the_permalink() ?>>
                        <div class="ui grid compact">
                           
               
                           <div class="three wide column" style="padding:3px;"> 
                              <?php the_post_thumbnail('full');?>
                           </div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;"><?php the_title();?></h4>
                              <small>NHL</small>
                         
                           </div>
                        </div>
                     </a>
                      <?php endwhile;?>
                     <!-- <a class="item blog_block" href="http://www.freesupertips.co.uk/fantasy-premier-league-gw16-need-know/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="28" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/chrome_2017-08-09_01-38-57.png" class="floated left new-thumb wp-post-image" alt="Fantasy Premier League 2017"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">Fantasy Premier League GW16 – All You Need to Know</h4>
                              <small>Premier League</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/fst-christmas-prizes-won-throughout-december/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="100" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/FST_Xmas_Logo_Snow-100x100.jpg" class="floated left new-thumb wp-post-image" alt="" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-100x100.jpg 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-150x150.jpg 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-360x360.jpg 360w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-768x768.jpg 768w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-200x200.jpg 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow-50x50.jpg 50w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/FST_Xmas_Logo_Snow.jpg 1000w" sizes="(max-width: 100px) 100vw, 100px"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">FST Christmas - Prizes to be Won throughout December!</h4>
                              <small></small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/611-bttswin-accumulator-lands-saturday/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="100" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/PA-33974234-min-100x100.jpg" class="floated left new-thumb wp-post-image" alt="Celtic" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/12/PA-33974234-min-100x100.jpg 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/PA-33974234-min-150x150.jpg 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/PA-33974234-min-200x200.jpg 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/12/PA-33974234-min-50x50.jpg 50w" sizes="(max-width: 100px) 100vw, 100px"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">61/1 BTTS+Win Treble lands on Saturday afternoon!</h4>
                              <small>Football</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/fantasy-premier-league-gw15-need-know/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="28" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/chrome_2017-08-09_01-38-57.png" class="floated left new-thumb wp-post-image" alt="Fantasy Premier League 2017"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">Fantasy Premier League GW15 – All You Need to Know</h4>
                              <small>Premier League</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/191-nba-accumulator-lands-monday-night/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="100" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/Untitled-100x100.png" class="floated left new-thumb wp-post-image" alt="" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Untitled-100x100.png 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Untitled-150x150.png 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Untitled-200x200.png 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Untitled-50x50.png 50w" sizes="(max-width: 100px) 100vw, 100px"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">19/1 NBA Accumulator lands on Monday night!</h4>
                              <small>NBA</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/fantasy-premier-league-gw14-need-know/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="28" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/chrome_2017-08-09_01-38-57.png" class="floated left new-thumb wp-post-image" alt="Fantasy Premier League 2017"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">Fantasy Premier League GW14 – All You Need to Know</h4>
                              <small>Premier League</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/fantasy-premier-league-gw13-need-know/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="28" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/chrome_2017-08-09_01-38-57.png" class="floated left new-thumb wp-post-image" alt="Fantasy Premier League 2017"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">Fantasy Premier League GW13 - All You Need to Know</h4>
                              <small>Premier League</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/1001-yourodds-lands-sunday/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="100" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/Screen-Shot-2017-11-19-at-12.55.21-100x100.png" class="floated left new-thumb wp-post-image" alt="" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Screen-Shot-2017-11-19-at-12.55.21-100x100.png 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Screen-Shot-2017-11-19-at-12.55.21-150x150.png 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Screen-Shot-2017-11-19-at-12.55.21-200x200.png 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/Screen-Shot-2017-11-19-at-12.55.21-50x50.png 50w" sizes="(max-width: 100px) 100vw, 100px"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">100/1 #YourOdds Special lands on Sunday!</h4>
                              <small>Football</small>
                           </div>
                        </div>
                     </a>
                     <a class="item blog_block" href="http://www.freesupertips.co.uk/161-win-accumulator-lands-thursday-night/">
                        <div class="ui grid compact">
                           <div class="three wide column" style="padding:3px;"> <img width="100" height="100" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/16-1-win-acca-100x100.jpg" class="floated left new-thumb wp-post-image" alt="" srcset="http://www.freesupertips.co.uk/wp-content/uploads/2017/11/16-1-win-acca-100x100.jpg 100w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/16-1-win-acca-150x150.jpg 150w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/16-1-win-acca-200x200.jpg 200w, http://www.freesupertips.co.uk/wp-content/uploads/2017/11/16-1-win-acca-50x50.jpg 50w" sizes="(max-width: 100px) 100vw, 100px"></div>
                           <div class="thirteen wide column" style="padding:3px; height:50px; overflow:hidden; text-overflow: ellipsis;">
                              <h4 class="ui header" style="margin:6px 0px 2px 0px;">16/1 Win Accumulator lands on Thursday night!</h4>
                              <small>Football</small>
                           </div>
                        </div>
                     </a> -->
                  </div>
                  <!-- END UI LIST --> <!-- END BLOG --><!-- end hide blog on festive five pages --> 

  <!-- START TWITTER  -->
                  <div class="ui horizontal divider"><i class="ui white custom twitter icon"></i> Twitter</div>
                  <!-- <div id="twitter-widget-wrapper"><iframe id="twitter-widget-1" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" class="twitter-timeline twitter-timeline-rendered" style="position: static; visibility: visible; display: inline-block; width: 520px; padding: 0px; border: none; max-width: 100%; min-width: 180px; margin-top: 0px; margin-bottom: 0px; height: 2454.98px;" data-widget-id="580362237879193600" title="Twitter Timeline" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/saved_resource.html"></iframe></div>
                  <br>
                  <center><iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" class="twitter-follow-button twitter-follow-button-rendered" title="Twitter Follow Button" src="./Free Sports Betting Tips &amp; Free Bets, Football Predictions1_files/follow_button.6b8337773e8a8ecc4f0b054fec8f1482.en.html" style="position: static; visibility: visible; width: 244px; height: 20px;" data-screen-name="FootySuperTips"></iframe></center> -->
                  <!-- END TWITTER --> <!-- START FACEBOOK<div class="ui horizontal divider" style="margin-top:10px;"><i class="ui big red facebook icon" style="margin: 10px;"></i> Facebook</div><div id="facebookwrapper"><div class="fb-page" data-href="https://www.facebook.com/Football.Super.Tips/" data-tabs="timeline" data-width="800" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"></div></div> END FACEBOOK -->
                  <blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Let&#39;s hear your best bet for the Utah Jazz vs San Antonio Spurs match in the NBA tonight! 👇<br><br>Tips and Detailed Match Preview HERE ▶️ <a href="https://t.co/2jPilynDga">https://t.co/2jPilynDga</a> <a href="https://t.co/wXBncMrUXk">pic.twitter.com/wXBncMrUXk</a></p>&mdash; Football Super Tips (@FootySuperTips) <a href="https://twitter.com/FootySuperTips/status/943984427566288896?ref_src=twsrc%5Etfw">December 21, 2017</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Staying up late for the NBA?<br><br>Our featured match preview has tips for the Utah Jazz vs San Antonio Spurs game! 🏀<br><br>Read and back them HERE ▶️ <a href="https://t.co/2jPilyFe7I">https://t.co/2jPilyFe7I</a> <a href="https://t.co/eckCybeoUx">pic.twitter.com/eckCybeoUx</a></p>&mdash; Football Super Tips (@FootySuperTips) <a href="https://twitter.com/FootySuperTips/status/943969328189149184?ref_src=twsrc%5Etfw">December 21, 2017</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">TAP ❤️ if you were on our 12/1 BTTS Acca winner last night!<br><br>GET £30 Free Bets to back tonight&#39;s Tips with Betway! 💰<br><br>JOIN HERE ▶️ <a href="https://t.co/GIFR0OkSty">https://t.co/GIFR0OkSty</a><br><br>New Customers offer, T&amp;Cs Apply, 18+ <a href="https://t.co/0nHii4PfQX">pic.twitter.com/0nHii4PfQX</a></p>&mdash; Football Super Tips (@FootySuperTips) <a href="https://twitter.com/FootySuperTips/status/943891313807593472?ref_src=twsrc%5Etfw">December 21, 2017</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

               </div>
               <!-- end six wide column -->